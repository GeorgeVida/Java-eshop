import java.util.ArrayList;

public class Shop {
	
	private String namesh;
	private int idsh;
	private static int count;
	private String addresssh;
	private String phonenumbersh;
	protected static ArrayList<Shop> shop= new ArrayList<Shop>();
	protected ArrayList<Product> products= new ArrayList<Product>();

	public Shop(String namesh, String addresssh, String phonenumbersh) {
		this.namesh = namesh;
		count++;
		idsh=count;
		this.addresssh = addresssh;
		this.phonenumbersh=phonenumbersh;
	}
	
	public String getNamesh() {
		return namesh;
	}


	public int getIdsh() {
		return idsh;
	}

	

	public String getAddresssh() {
		return addresssh;
	}

	
	public String getPhonenumbersh() {
		return phonenumbersh;
	}

	
	@Override
	public String toString() {
		return "��������� ��������: " + namesh + ", id: " + idsh + ", ���������: " + addresssh + ", ��������: "
				+ phonenumbersh + "]";
	}

	public static void printAllShops() {
		for(int i=0; i< shop.size(); i++) {
			System.out.println(shop.get(i).toString());
		}
	}

	public static void filterAndPrintShops(String input) {
		int total=0;
		for(int i=0; i< shop.size(); i++) {
			if(shop.get(i).getNamesh().toLowerCase().contains(input.toLowerCase())) {
				System.out.println(shop.get(i).toString());
				total+=1;
			}
		}
		
		if(total==0) {
			System.out.println("��� �������� ����������� �� ���� �� �����.");
		}
	}
	
	public static Shop searchById(int x) {
		for(int i=0; i< shop.size(); i++) {
			if(shop.get(i).getIdsh()==x) {
				return shop.get(i);
			}
		}
		return null;
	}
	
	public int productIdExists(int id) {
		for(int i=0; i< products.size(); i++) {
			if(products.get(i).getIdp()==id) {
				return i;
			}
			
		}
		return -1;
		
	}
	
	public String printProductName(int id) {
		return products.get(productIdExists(id)).getNamep();
	}
	public double printProductPrice(int id) {
		return products.get(productIdExists(id)).getPrice();
	}
	public void printCatalogue() {
		for(int i=0;i<products.size();i++) {
		    System.out.print("Id ���������: "+products.get(i).getIdp()+", ����� ���������: "
		    		+printProductName(products.get(i).getIdp()));
		    System.out.printf(", ���� ��� �������: %.2f�\n",printProductPrice(products.get(i).getIdp()));
		}
	}
}
