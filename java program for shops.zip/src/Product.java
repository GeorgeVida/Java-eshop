
public class Product {
	
	private int idp;
	private static int count;
	private String namep;
	private double price;
	
	public Product(String namep, double price) {
		count++;
		idp = count;
		this.namep = namep;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [idp=" + idp + ", namep=" + namep + ", price=" + price + "]";
	}

	public int getIdp() {
		return idp;
	}


	public String getNamep() {
		return namep;
	}

	public double getPrice() {
		return price;
	}

	
	
	
	
}
