import java.util.ArrayList;
public abstract class Customer {
	private String name;
	private String phonenumber;
	private String address;
	protected static ArrayList<Customer> customer= new ArrayList<Customer>();

	public Customer(String name, String phonenumber, String address) {
		this.name = name;
		this.phonenumber = phonenumber;
		this.address = address;
		customer.add(this);
	}
	
	public String getName() {
		return name;
	}


	public String getPhonenumber() {
		return phonenumber;
	}

	public String getAddress() {
		return address;
	}

	public abstract void getMenu();

	
	
}
